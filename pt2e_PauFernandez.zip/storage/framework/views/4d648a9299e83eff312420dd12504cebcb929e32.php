<!-- Navigation -->
<nav>
    <?php if(Auth::check()): ?> 
        <b>Has fet login com a: <?php echo e(Auth::user()->name); ?></b>
        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
        </form><br>
    <?php endif; ?>
    <a href="<?php echo e(route('home')); ?>">Inici</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('llibre_list')); ?>">Llibres</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('autor_list')); ?>">Autors</a>
    
    <?php if(!Auth::check()): ?> 
            &nbsp;&nbsp;&nbsp;
            <a href="<?php echo e(route('login')); ?>">Login</a>
            &nbsp;&nbsp;&nbsp;
            <a href="<?php echo e(route('register')); ?>">Register</a>
    <?php endif; ?>
</nav>
<?php /**PATH /var/www/html/pt2e/resources/views/navbar.blade.php ENDPATH**/ ?>